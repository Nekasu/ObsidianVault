
>[!warning] 提示
>推荐使用 [obsidian 软件](https://obsidian.md/), 以获得最好的阅读体验
>点击右上角「书本」![](https://raw.githubusercontent.com/Nekasu/Blog_pics/main/20240910163022.png)图标, 进入阅读模式, 以获得更好的阅读体验！
>
>作者：Nekasu/周肖桐

众所周知, 学校的服务器只能通过学校的内网连接. 如果在校外, 则无法连接, 那么有什么方法能解决呢？

可以使用 Zerotier 进行内网穿透, 为此, 我们需要一个 Zerotier 的账户充当管理员. 

## Zeroteir 管理员

- [[使用Zerotier进行内网穿透_面向管理员]]

## Zerotier 普通用户

如果你们已经有了一个管理员, 则可以直接按照以下步骤加入 zerotier 网络
- [[使用Zerotier进行内网穿透_面向用户]]

## 使用加速服务

如果觉得网络不稳定, 可以考虑使用 moon 服务器, 具体教程请看
- [[使用Zerotier进行内网穿透_使用阿里云]]