
>[!warning] 提示
>推荐使用 [obsidian 软件](https://obsidian.md/), 以获得最好的阅读体验
>点击右上角「书本」![](https://raw.githubusercontent.com/Nekasu/Blog_pics/main/20240910163022.png)图标, 进入阅读模式, 以获得更好的阅读体验！
>
>作者：Nekasu/周肖桐


```cardlink
url: https://www.cnblogs.com/mq0036/p/17902946.html
title: "ZeroTier 内网穿透，并搭建 moon 中转服务器 - jack_Meng - 博客园"
description: "前言 由于本系列是建立在个人 NAS 的基础上，所以最好不要通过域名、公网 IP 等访问。 本文以广泛使用的 ZeroTier 为例。当然，后面也会给出大部分可用的内网穿透方法链接，可自行参考。 预先准备： 注册 ZeroTier 服务 NAS 主机 客户端主机 进阶准备： moon 中转服务器。"
host: www.cnblogs.com
```

在第 33 页与 34 页的“设备连入 moon 服务器”中, 建议使用“手动配置”而非“自动配置”

![[ZeroTier 内网穿透，并搭建 moon 中转服务器 - jack_Meng - 博客园.pdf]]