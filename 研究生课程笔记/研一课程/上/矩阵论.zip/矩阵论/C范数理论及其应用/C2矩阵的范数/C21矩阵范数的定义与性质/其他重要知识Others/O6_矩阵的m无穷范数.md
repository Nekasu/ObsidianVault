仿照向量[[O4_无穷范数|无穷范数]]的定义, 可以建立矩阵的$m_{\infty}$范数, 其定义如下：

设矩阵$A=(a_{ij})_{n\times n}\in C^{n\times n}$ , 则有矩阵的$m_\infty$范数$\Vert A \Vert_{m_\infty}$ 
$$\Vert A\Vert_{m_\infty}=n\cdot  \max_{i,j} \vert a_{ij}\vert$$

其含义为矩阵中模长最大的元素的$n$倍