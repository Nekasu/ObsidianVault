理解了度量矩阵 (Gram矩阵、格拉姆矩阵)
1. $$A=\begin{bmatrix}\vec e_1&\vec e_2&\cdots&\vec e_n\end{bmatrix}\cdot\begin{bmatrix}\vec e_1\\\vec e_2\\\vdots\\\vec e_n\end{bmatrix}$$
2. $$a_{ij}=(\vec e_i, \vec e_j)$$