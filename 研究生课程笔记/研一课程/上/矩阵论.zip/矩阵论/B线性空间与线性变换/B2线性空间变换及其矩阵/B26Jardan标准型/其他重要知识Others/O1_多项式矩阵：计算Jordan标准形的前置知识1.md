关于$\lambda$的多项式矩阵是一个这样的矩阵, $$A(\lambda)=\begin{bmatrix}a_{11}(\lambda)&a_{12}(\lambda)& \cdots& a_{1n}(\lambda)\\a_{21}(\lambda)&a_{22}(\lambda)&\cdots&a_{2n}(\lambda)\\\vdots& \vdots& & \vdots\\a_{
n1}(\lambda)&a_{n2}(\lambda)&\cdots&a_{nn}(\lambda) \end{bmatrix}$$
其中$a_{ij}(\lambda)$都是一个有关$\lambda$的多项式