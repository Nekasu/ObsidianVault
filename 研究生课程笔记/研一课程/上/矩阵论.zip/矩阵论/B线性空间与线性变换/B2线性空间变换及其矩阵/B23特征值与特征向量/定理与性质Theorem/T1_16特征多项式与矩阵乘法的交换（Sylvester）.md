1. 两个设定：
	1. 设$A\in R^{m\times n}, B\in R^{n\times m}$
	2. 设$AB$的特征多项式为$\varphi_{AB}(\lambda)$ 
2. 一个结论：
	1. 则有$\lambda^n\varphi_{AB}(\lambda)=\lambda^m\varphi_{BA}(\lambda)$ 