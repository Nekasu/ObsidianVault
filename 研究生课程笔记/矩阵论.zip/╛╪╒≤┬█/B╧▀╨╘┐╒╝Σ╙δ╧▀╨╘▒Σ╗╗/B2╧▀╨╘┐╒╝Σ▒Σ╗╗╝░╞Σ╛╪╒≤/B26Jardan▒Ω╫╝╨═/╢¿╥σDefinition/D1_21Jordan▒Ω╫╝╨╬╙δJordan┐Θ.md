我们称[[T1_28Jardan引理]]中的矩阵$J$为<mark style="background: #FFB86CA6;">Jordan标准形</mark>, 并称矩阵$J$中的$J_i(\lambda_i)$为<mark style="background: #FFB86CA6;">Jordan块</mark>

这里贴上![[T1_28Jardan引理]]