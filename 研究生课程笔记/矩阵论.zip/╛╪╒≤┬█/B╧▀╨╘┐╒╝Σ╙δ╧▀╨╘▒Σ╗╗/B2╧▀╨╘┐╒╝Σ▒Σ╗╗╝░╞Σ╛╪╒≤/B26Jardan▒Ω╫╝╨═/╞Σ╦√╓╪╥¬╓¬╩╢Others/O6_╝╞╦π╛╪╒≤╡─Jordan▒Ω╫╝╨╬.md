在复数域$C$上, 求矩阵$A$的Jordan标准形的步骤如下

# Step1 求不变因子与初等因子组

1. [[O3_不变因子的定义及其求法：计算Jordan标准形的前置知识3|求不变因子]]  
2. [[O4_初等因子组及其求法：计算Jordan标准形的前置知识4|求初等因子组]]
	1. 不妨设求出初等因子组为$$(\lambda-\lambda_1)^{m_1},(\lambda-\lambda_2)^{m_2},\cdots,(\lambda-\lambda_s)^{m_s}$$
# Step2 写出每个初等因子对应的Jordan块

对于初等因子$(\lambda-\lambda_i)^{m_i}$, 有对应的Jordan块$$J_i(\lambda_i)=\begin{bmatrix}\lambda_i
&1& & & \\ & \lambda_i&1& & \\& & \lambda_i&\ddots& \\& & & \ddots&1\\& & & & \lambda_i\end{bmatrix}_{m_i\times m_i}$$也即初等因子的代数重数为Jordan块的维度(希望每个几何重数为$m_i$的特征值都能张成一个$m_i$维空间) 

# Step3 将Jordan块写成Jordan标准形

很简单, 不赘述

$$A\sim J, J=\begin{bmatrix}J_1(\lambda_1)& & & \\ & J_2(\lambda_2)& &  \\ & & \ddots& \\ & & & J_s(\lambda_s)\end{bmatrix}$$